# 通用食材营养样品补充 concept-enrichment-2026-10-03.1

15 个新增样品；累计 46 个限定范围参考，覆盖 44 个食材概念。

本包仅追加食材营养参考。20 份配方计算原样保留用于核对，导入时不写菜谱、厨具或通用营养列。参考需要确认品种、加工、可食部与称量条件，不自动绑定食材。原方仍为 8 份完整四项估算。

来源：[TFDA](https://data.gov.tw/dataset/8543)，政府資料開放授權條款-第1版；原有 USDA 来源及快照保留在来源锁和证据文件中。所有值可逐项核对，不补零。

在初始化并已有概念目录的 PostgreSQL 上，使用含本版本脚本的仓库运行：

```sh
ENRICHMENT_MANIFEST_SHA256="$(shasum -a 256 /绝对路径/补充包/manifest.json | cut -d " " -f 1)" node server/scripts/import-nutrition-enrichment.mjs /绝对路径/补充包
```

通过外部 SHA256 核对 ZIP 后再解压。命令从环境读取 DATABASE_URL，默认演练回滚；加 --apply 才提交。重复执行不写入，冲突回滚，拒绝降级。新安装先导入基础目录；本包不替代基础安装包。以后不要使用历史 ZIP 自带旧导入器覆盖新引用。
